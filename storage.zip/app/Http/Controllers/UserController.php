<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;

class UserController extends Controller
{


	public function postSignUp(Request $request)
	{
		$this->validate($request,[
			'email' => 'required|email|unique:users',
			'first_name' => 'required|max:120',
			'password' => 'required|min:4'
		]);

		$email = $request['email'];
		$first_name = $request['first_name'];
		$password = bcrypt($request['password']);

		$user = new User();

		$user->email = $email;
		$user->first_name = $first_name;
		$user->password = $password;

		$user->save();

		Auth::login($user);

		return redirect()->route('dashboard');
	}

	public function postSignIn(Request $request)
	{
		$this->validate($request,[
			'email' => 'required|email|',
			'password' => 'required|min:4'
		]);

		if(Auth::attempt(['email' => $request['email'], 'password' => $request['password']]))
		{
			return redirect()->route('dashboard');
		} 
		
		return redirect()->back();
	}

	public function getLogout()
	{
		Auth::logout();
		return redirect()->route('home');
	}

	public function getAccount()
	{
		return view('account', ['user' => Auth::user()]);
	}

	public function postSaveAccount(Request $request)
	{
		$this->validate($request, [
			'first_name' => 'required|max:120',
		]);

		$user = Auth::user();
		$user->first_name = $request['first_name'];
		$user->update();

		$file = $request->file('image'); //getting the file from request

		$filename = $request['first_name'] . '-' . $user->id . '.jpg'; //setting a file name for the file, so it's unique
		
		if($file) {

			Storage::disk('local')->put($filename, File::get($file)); //takes the file and saves it as $filename on disk 
			//helper which allows us to access laravel's storage engine, allows us to store files of any kind on our file system
			//can configure in filesystems.php
		}
		return redirect()->route('account');
	}

	public function getUserImage($filename)
	{
		$file = Storage::disk('local')->get($filename);
		return new Response($file, 200); //because the route that calls this is accessed through SRC in img
										//we don't want to redirect anything, instead we want to provide the file
										//we do this by returning a response because this is called by our IMG element
										// which WANTS a file
		
	}
}